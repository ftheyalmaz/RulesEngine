﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Linq.Dynamic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;

namespace RuleEngine
{
    internal class Program
    {

        static void Main(string[] args)
        {
            //Setting up the database interaction object and connecting to the DB
            string connectionString = "Server=dev1.layeronesoftware.com;Database=FTBTrade;Integrated Security=SSPI;";
            DatabaseInteraction dbInteraction = new DatabaseInteraction(connectionString);
            dbInteraction.OpenConnection();


            //Records on which to run our compliance rules and expressions
            List<TempPQLResult> tempPQLResults = dbInteraction.GetAllFromTable("dbo.TempPQLResult");


            //Setting up the context/scope of the expression in the form
            //of parameters we pass upon execution, for now the only provided context
            //is the record on which we are applying our rules
            List<HFLib.ContextParameter> parameters = new List<HFLib.ContextParameter>();
            parameters.Add(new HFLib.ContextParameter { Name = "TempPQLResult", ParameterType = typeof(TempPQLResult) });


            //Here we declare our string expression and test ParseExpressionStrToTree()
            const string exp = "TempPQLResult.StartPriceN > 50 && TempPQLResult.Manager == \"Courtney Carson\"";
            Expression parseTree = HFLib.ParseExpressionStrToTree(exp, parameters);
            //Console.WriteLine("exp: " + parseTree.ToString());
            //HFLib.PrintPreOrder(parseTree);

            //Here we upload the tree to the database
            dbInteraction.PostTreeToDB(parseTree);

            //Here we test ExecuteOn() on parseTree with each record in TempPQLResult,
            //and output results  
            foreach (TempPQLResult record in tempPQLResults)
            {
                bool passed = HFLib.ExecuteOn(parseTree, record);
                string toPrint = "Compliance Result: { Strategy: " + record.Strategy;
                toPrint += ", Security Type: " + record.SecurityType;
                toPrint += ", Clearing Broker: " + record.ClearingBroker;
                toPrint += ", Sid: " + record.Sid;
                toPrint += ", Start Price [N]: " + record.StartPriceN;
                toPrint += ", Manager: " + record.Manager;
                toPrint += ", COMPLIANCE RESULT: " + passed + " }";
               // Console.WriteLine(toPrint);
            }



            dbInteraction.CloseConnection();
        }


    }
    
}






