﻿using RuleDatabaseObjects;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine
{
    internal class DatabaseInteraction
    {
        private string connectionString;

        private SqlConnection dbConnection;


        public DatabaseInteraction(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public void OpenConnection()
        {
            dbConnection = new SqlConnection(connectionString);
            dbConnection.Open();  
        }

        public void CloseConnection()
        {
            dbConnection.Close();
        }

        public static RuleDatabaseObjects.ExpressionType CreateExpressionType(System.Linq.Expressions.Expression e)
        {
            return new RuleDatabaseObjects.ExpressionType
            {
                Description = e.NodeType.ToString(),
                Created = DateTime.Now,
                Version = 1,
                LastUpdate = DateTime.Now,
                ApplicationSource = "AppSourcePlaceholder",
                SystemSource = "SystemSourcePlaceholder",
                GlobalVersion = 1
            };
        }

        public static RuleDatabaseObjects.ExpressionValueType CreateExpressionValueType(System.Linq.Expressions.Expression e)
        {
            return new RuleDatabaseObjects.ExpressionValueType
            {
                Description = e.Type.ToString(),
                Created = DateTime.Now,
                Version = 1,
                LastUpdate = DateTime.Now,
                ApplicationSource = "AppSourcePlaceholder",
                SystemSource = "SystemSourcePlaceholder",
                GlobalVersion = 1
            };
        }

        public static RuleDatabaseObjects.Expression CreateExpression(System.Linq.Expressions.Expression e, int parentNodeId)
        {
            var expressionType = CreateExpressionType(e);
            var expressionValueType = CreateExpressionValueType(e);

            
            int expTypeId = new Random().Next(); 
            int expValType = new Random().Next();

            return new RuleDatabaseObjects.Expression
            {
                // FIX RuleId, ExpessionTypeId, ExpressionValueType and ParentExpressionId
                //and ExpressionCallRuleId
                RuleId = 7, 
                ExpressionTypeId = 1,
                ExpressionValue = e.ToString(),
                ExpressionValueType = 1,
                Created = DateTime.Now,
                Version = 1,
                LastUpdate = DateTime.Now,
                ApplicationSource = "AppSourcePlaceholder",
                SystemSource = "SystemSourcePlaceholder",
                GlobalVersion = 1
            };
        }

        internal void postTreeHelper(System.Linq.Expressions.Expression e, 
            List<RuleDatabaseObjects.Expression> expList,
            List<RuleDatabaseObjects.ExpressionType> expTypeList,
            List<RuleDatabaseObjects.ExpressionValueType> expValList, int parentNodeId = 0)
        {
            if (e == null) return;

            // Generate and add objects for this node
            expTypeList.Add(CreateExpressionType(e));
            expValList.Add(CreateExpressionValueType(e));
            expList.Add(CreateExpression(e, parentNodeId)); //FIX CreateExpression()

            // Get child expressions and recursively add them
            foreach (var child in HFLib.GetChildExpressions(e))
            {
                postTreeHelper(child, expList, expTypeList, expValList,  parentNodeId + 1); //FIX parentNodeId
            }
        }

        internal void PostTreeToDB(System.Linq.Expressions.Expression e)
        {
            List<RuleDatabaseObjects.Expression> eList = new List<RuleDatabaseObjects.Expression>();    
            List<RuleDatabaseObjects.ExpressionType> eTList = new List<RuleDatabaseObjects.ExpressionType>();
            List<RuleDatabaseObjects.ExpressionValueType> eVList = new List<RuleDatabaseObjects.ExpressionValueType>();

            postTreeHelper(e, eList, eTList, eVList);

            UploadToDatabase(eTList, eVList, eList);
        }

        public void UploadToDatabase(List<RuleDatabaseObjects.ExpressionType> expressionTypes,
                                        List<RuleDatabaseObjects.ExpressionValueType> expressionValueTypes,
                                        List<RuleDatabaseObjects.Expression> expressions)
        {

                foreach (var expressionType in expressionTypes)
                {
                    string insertExpressionType = @"INSERT INTO Rules.ExpressionType(Description, Created, Version, LastUpdate, Application_source, System_source, _GlobalVersion) 
                                               VALUES(@Description, @Created, @Version, @LastUpdate, @ApplicationSource, @SystemSource, @GlobalVersion)";

                    using (SqlCommand cmd = new SqlCommand(insertExpressionType, dbConnection))
                    {
                        cmd.Parameters.AddWithValue("@Description", expressionType.Description);
                        cmd.Parameters.AddWithValue("@Created", expressionType.Created);
                        cmd.Parameters.AddWithValue("@Version", expressionType.Version);
                        cmd.Parameters.AddWithValue("@LastUpdate", expressionType.LastUpdate);
                        cmd.Parameters.AddWithValue("@ApplicationSource", expressionType.ApplicationSource);
                        cmd.Parameters.AddWithValue("@SystemSource", expressionType.SystemSource);
                        cmd.Parameters.AddWithValue("@GlobalVersion", expressionType.GlobalVersion);

                        cmd.ExecuteNonQuery();
                    }
                }

                foreach (var expressionValueType in expressionValueTypes)
                {
                    string insertExpressionValueType = @"INSERT INTO Rules.ExpressionValueType(Description, Created, Version, LastUpdate, Application_source, System_source, _GlobalVersion) 
                                                    VALUES(@Description, @Created, @Version, @LastUpdate, @ApplicationSource, @SystemSource, @GlobalVersion)";

                    using (SqlCommand cmd = new SqlCommand(insertExpressionValueType, dbConnection))
                    {
                        cmd.Parameters.AddWithValue("@Description", expressionValueType.Description);
                        cmd.Parameters.AddWithValue("@Created", expressionValueType.Created);
                        cmd.Parameters.AddWithValue("@Version", expressionValueType.Version);
                        cmd.Parameters.AddWithValue("@LastUpdate", expressionValueType.LastUpdate);
                        cmd.Parameters.AddWithValue("@ApplicationSource", expressionValueType.ApplicationSource);
                        cmd.Parameters.AddWithValue("@SystemSource", expressionValueType.SystemSource);
                        cmd.Parameters.AddWithValue("@GlobalVersion", expressionValueType.GlobalVersion);

                        cmd.ExecuteNonQuery();
                    }
                }

                foreach (var expression in expressions)
                {
                    string insertExpression = @"INSERT INTO Rules.Expression(RuleId, ParentExpressionId, ExpressionTypeId, ExpressionValue, ExpressionValueType, Created, Version, LastUpdate, Application_source, System_source, _GlobalVersion) 
                                           VALUES(@RuleId, @ParentExpressionId, @ExpressionTypeId, @ExpressionValue, @ExpressionValueType, @Created, @Version, @LastUpdate, @ApplicationSource, @SystemSource, @GlobalVersion)";

                    using (SqlCommand cmd = new SqlCommand(insertExpression, dbConnection))
                    {
                        cmd.Parameters.AddWithValue("@RuleId", expression.RuleId);
                        cmd.Parameters.AddWithValue("@ParentExpressionId", expression.ParentExpressionId.HasValue ? (object)expression.ParentExpressionId.Value : DBNull.Value);
                        cmd.Parameters.AddWithValue("@ExpressionTypeId", expression.ExpressionTypeId);
                        cmd.Parameters.AddWithValue("@ExpressionValue", expression.ExpressionValue);
                        cmd.Parameters.AddWithValue("@ExpressionValueType", expression.ExpressionValueType.HasValue ? (object)expression.ExpressionValueType.Value : DBNull.Value);
                        cmd.Parameters.AddWithValue("@Created", expression.Created);
                        cmd.Parameters.AddWithValue("@Version", expression.Version);
                        cmd.Parameters.AddWithValue("@LastUpdate", expression.LastUpdate);
                        cmd.Parameters.AddWithValue("@ApplicationSource", expression.ApplicationSource);
                        cmd.Parameters.AddWithValue("@SystemSource", expression.SystemSource);
                        cmd.Parameters.AddWithValue("@GlobalVersion", expression.GlobalVersion);

                        cmd.ExecuteNonQuery();
                    }
                }
            
        }


    public List<TempPQLResult> GetAllFromTable(string table)
        {
            List<TempPQLResult> result = new List<TempPQLResult>();
            string query = $"SELECT * FROM {table}";

            using (SqlCommand command = new SqlCommand(query, dbConnection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        TempPQLResult trade = new TempPQLResult
                        {
                            Strategy = reader["Strategy"].ToString(),
                            SecurityType = reader["Security Type"].ToString(),
                            ClearingBroker = reader["Clearing Broker"].ToString(),
                            Sid = (int)reader["Sid"],
                            Ticker = reader["Ticker"].ToString(),
                            SecurityDescription = reader["Security Description"].ToString(),
                            StartPriceN = Convert.ToDouble(reader["Start Price N"]),
                            EndPriceN = Convert.ToDouble(reader["End Price N"]),
                            EndQuantity = reader["End Quantity"].ToString(),
                            QuantityChange = Convert.ToDouble(reader["Quantity Change"]),
                            StartOTE = reader["Start OTE"].ToString(),
                            EndOTE = reader["End OTE"].ToString(),
                            RealizedPL = Convert.ToDouble(reader["Realized P&L"]),
                            TotalPL = Convert.ToDouble(reader["Total P&L"]),
                            EndMarketValue = reader["End Market Value"].ToString(),
                            Manager = reader["Manager"].ToString(),
                            LegalEntity = reader["Legal Entity"].ToString()
                        };
                        result.Add(trade);
                        //Console.WriteLine("{" + $"Strategy: {trade.Strategy}, Security Type: {trade.SecurityType}, Clearing Broker: {trade.ClearingBroker}, Sid: {trade.Sid}, Ticker: {trade.Ticker}, Security Description: {trade.SecurityDescription}, Start Price N: {trade.StartPriceN}, End Price N: {trade.EndPriceN}, End Quantity: {trade.EndQuantity}, Quantity Change: {trade.QuantityChange}, Start OTE: {trade.StartOTE}, End OTE: {trade.EndOTE}, Realized P&L: {trade.RealizedPL}, Total P&L: {trade.TotalPL}, End Market Value: {trade.EndMarketValue}, Manager: {trade.Manager}, Legal Entity: {trade.LegalEntity}" + "}");
                    }
                }
            }
            return result;
        }

        public void DisplayTradeRecords()
        {
            string query = "SELECT * FROM dbo.TempPQLResult";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            TempPQLResult trade = new TempPQLResult
                            {
                                Strategy = reader["Strategy"].ToString(),
                                SecurityType = reader["Security Type"].ToString(),
                                ClearingBroker = reader["Clearing Broker"].ToString(),
                                Sid = (int)reader["Sid"],
                                Ticker = reader["Ticker"].ToString(),
                                SecurityDescription = reader["Security Description"].ToString(),
                                StartPriceN = Convert.ToDouble(reader["Start Price N"]),
                                EndPriceN = Convert.ToDouble(reader["End Price N"]),
                                EndQuantity = reader["End Quantity"].ToString(),
                                QuantityChange = Convert.ToDouble(reader["Quantity Change"]),
                                StartOTE = reader["Start OTE"].ToString(),
                                EndOTE = reader["End OTE"].ToString(),
                                RealizedPL = Convert.ToDouble(reader["Realized P&L"]),
                                TotalPL = Convert.ToDouble(reader["Total P&L"]),
                                EndMarketValue = reader["End Market Value"].ToString(),
                                Manager = reader["Manager"].ToString(),
                                LegalEntity = reader["Legal Entity"].ToString()
                            };

                            Console.WriteLine("{"+$"Strategy: {trade.Strategy}, Security Type: {trade.SecurityType}, Clearing Broker: {trade.ClearingBroker}, Sid: {trade.Sid}, Ticker: {trade.Ticker}, Security Description: {trade.SecurityDescription}, Start Price N: {trade.StartPriceN}, End Price N: {trade.EndPriceN}, End Quantity: {trade.EndQuantity}, Quantity Change: {trade.QuantityChange}, Start OTE: {trade.StartOTE}, End OTE: {trade.EndOTE}, Realized P&L: {trade.RealizedPL}, Total P&L: {trade.TotalPL}, End Market Value: {trade.EndMarketValue}, Manager: {trade.Manager}, Legal Entity: {trade.LegalEntity}"+"}");
                        }
                    }
                }
            }
        }

        public void DisplayRuleTypeRecords()
        {
            string query = "SELECT * FROM Rules.RuleType";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            RuleDatabaseObjects.RuleType ruleType = new RuleDatabaseObjects.RuleType
                            {
                                RuleTypeId = (int)reader["RuleTypeId"],
                                Description = reader["Description"].ToString(),
                                Created = reader["Created"] as DateTime?,
                                Version = reader["Version"] as int?,
                                LastUpdate = reader["LastUpdate"] as DateTime?,
                                ApplicationSource = reader["Application_Source"].ToString(),
                                SystemSource = reader["System_Source"].ToString(),
                                GlobalVersion = reader["_GlobalVersion"] as int?
                            };

                            Console.WriteLine("{"+$"RuleTypeId: {ruleType.RuleTypeId}, Description: {ruleType.Description}, Created: {ruleType.Created}, Version: {ruleType.Version}, LastUpdate: {ruleType.LastUpdate}, ApplicationSource: {ruleType.ApplicationSource}, SystemSource: {ruleType.SystemSource}, GlobalVersion: {ruleType.GlobalVersion}"+"}");
                        }
                    }
                }
            }
        }

        public void DisplayRuleRecords()
        {
            string query = "SELECT * FROM Rules.[Rule]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            RuleDatabaseObjects.Rule rule = new RuleDatabaseObjects.Rule
                            {
                                RuleId = (int)reader["RuleId"],
                                RuleName = reader["RuleName"].ToString(),
                                RuleTypeId = (int)reader["RuleTypeId"],
                                RuleCode = reader["RuleCode"].ToString(),
                                Created = reader["Created"] as DateTime?,
                                Version = reader["Version"] as int?,
                                LastUpdate = reader["LastUpdate"] as DateTime?,
                                ApplicationSource = reader["Application_Source"].ToString(),
                                SystemSource = reader["System_Source"].ToString(),
                                GlobalVersion = reader["_GlobalVersion"] as int?
                            };

                            Console.WriteLine("{"+$"RuleId: {rule.RuleId}, RuleName: {rule.RuleName}, RuleTypeId: {rule.RuleTypeId}, RuleCode: {rule.RuleCode}, Created: {rule.Created}, Version: {rule.Version}, LastUpdate: {rule.LastUpdate}, ApplicationSource: {rule.ApplicationSource}, SystemSource: {rule.SystemSource}, GlobalVersion: {rule.GlobalVersion}"+"}");
                        }
                    }
                }
            }
        }

        public void DisplayExpressionRecords()
        {
            string query = "SELECT * FROM Rules.Expression";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            RuleDatabaseObjects.Expression expression = new RuleDatabaseObjects.Expression
                            {
                                ExpressionId = (int)reader["ExpressionId"],
                                RuleId = (int)reader["RuleId"],
                                ParentExpressionId = reader["ParentExpressionId"] as int?,
                                ExpressionSequence = reader["ExpressionSequence"] as int?,
                                ExpressionTypeId = (int)reader["ExpressionTypeId"],
                                ExpressionCallRuleId = reader["ExpressionCallRuleId"] as int?,
                                ExpressionValue = reader["ExpressionValue"].ToString(),
                                ExpressionValueType = reader["ExpressionValueType"] as int?,
                                Created = reader["Created"] as DateTime?,
                                Version = reader["Version"] as int?,
                                LastUpdate = reader["LastUpdate"] as DateTime?,
                                ApplicationSource = reader["Application_Source"].ToString(),
                                SystemSource = reader["System_Source"].ToString(),
                                GlobalVersion = reader["_GlobalVersion"] as int?
                            };

                            Console.WriteLine("{"+$"ExpressionId: {expression.ExpressionId}, RuleId: {expression.RuleId}, ParentExpressionId: {expression.ParentExpressionId}, ExpressionSequence: {expression.ExpressionSequence}, ExpressionTypeId: {expression.ExpressionTypeId}, ExpressionCallRuleId: {expression.ExpressionCallRuleId}, ExpressionValue: {expression.ExpressionValue}, ExpressionValueType: {expression.ExpressionValueType}, Created: {expression.Created}, Version: {expression.Version}, LastUpdate: {expression.LastUpdate}, ApplicationSource: {expression.ApplicationSource}, SystemSource: {expression.SystemSource}, GlobalVersion: {expression.GlobalVersion}"+"}");
                        }
                    }
                }
            }
        }

        public void DisplayExpressionTypeRecords()
        {
            string query = "SELECT * FROM Rules.ExpressionType";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            RuleDatabaseObjects.ExpressionType expressionType = new RuleDatabaseObjects.ExpressionType
                            {
                                ExpressionTypeId = (int)reader["ExpressionTypeId"],
                                Description = reader["Description"].ToString(),
                                Created = reader["Created"] as DateTime?,
                                Version = reader["Version"] as int?,
                                LastUpdate = reader["LastUpdate"] as DateTime?,
                                ApplicationSource = reader["Application_Source"].ToString(),
                                SystemSource = reader["System_Source"].ToString(),
                                GlobalVersion = reader["_GlobalVersion"] as int?
                            };

                            Console.WriteLine("{"+$"ExpressionTypeId: {expressionType.ExpressionTypeId}, Description: {expressionType.Description}, Created: {expressionType.Created}, Version: {expressionType.Version}, LastUpdate: {expressionType.LastUpdate}, ApplicationSource: {expressionType.ApplicationSource}, SystemSource: {expressionType.SystemSource}, GlobalVersion: {expressionType.GlobalVersion}"+"}");
                        }
                    }
                }
            }
        }

        public void DisplayExpressionValueTypeRecords()
        {
            string query = "SELECT * FROM Rules.ExpressionValueType";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            RuleDatabaseObjects.ExpressionValueType expressionValueType = new RuleDatabaseObjects.ExpressionValueType
                            {
                                ExpressionValueTypeId = (int)reader["ExpressionValueTypeId"],
                                Description = reader["Description"].ToString(),
                                Created = reader["Created"] as DateTime?,
                                Version = reader["Version"] as int?,
                                LastUpdate = reader["LastUpdate"] as DateTime?,
                                ApplicationSource = reader["Application_Source"].ToString(),
                                SystemSource = reader["System_Source"].ToString(),
                                GlobalVersion = reader["_GlobalVersion"] as int?
                            };

                            Console.WriteLine("{"+$"ExpressionValueTypeId: {expressionValueType.ExpressionValueTypeId}, Description: {expressionValueType.Description}, Created: {expressionValueType.Created}, Version: {expressionValueType.Version}, LastUpdate: {expressionValueType.LastUpdate}, ApplicationSource: {expressionValueType.ApplicationSource}, SystemSource: {expressionValueType.SystemSource}, GlobalVersion: {expressionValueType.GlobalVersion}"+"}");
                        }
                    }
                }
            }
        }

        
    }
}
